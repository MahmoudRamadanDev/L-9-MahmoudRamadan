<?php  include('inc/header.php'); ?>

    <h1 class="text-center col-12 bg-danger py-3 text-white my-2">Delete User</h1>
  
   
<?php  include('inc/footer.php'); ?>

 
  