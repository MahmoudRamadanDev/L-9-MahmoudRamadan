<?php  include('inc/header.php'); ?>

    <h1 class="text-center col-12 bg-primary py-3 text-white my-2">Home Page</h1>
    <div class="row">
        <div class="col-sm-12">
            <table class="table">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>Mark</td>
                        <td>a@a.com</td>
                        <td>
                            <a class="btn btn-info" href="edit.php"> <i class="fa fa-edit"></i> </a>
                        </td>
                        <td>
                            <a class="btn btn-danger" href="delete.php"> <i class="fa fa-close"></i> </a>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">2</th>
                        <td>Mark</td>
                        <td>a@a.com</td>
                        <td>
                            <a class="btn btn-info" href="edit.php"> <i class="fa fa-edit"></i> </a>
                        </td>
                        <td>
                            <a class="btn btn-danger" href="delete.php"> <i class="fa fa-close"></i> </a>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">3</th>
                        <td>Mark</td>
                        <td>a@a.com</td>
                        <td>
                            <a class="btn btn-info" href="edit.php"> <i class="fa fa-edit"></i> </a>
                        </td>
                        <td>
                            <a class="btn btn-danger" href="delete.php"> <i class="fa fa-close"></i> </a>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">4</th>
                        <td>Mark</td>
                        <td>a@a.com</td>
                        <td>
                            <a class="btn btn-info" href="edit.php"> <i class="fa fa-edit"></i> </a>
                        </td>
                        <td>
                            <a class="btn btn-danger" href="delete.php"> <i class="fa fa-close"></i> </a>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">5</th>
                        <td>Mark</td>
                        <td>a@a.com</td>
                        <td>
                            <a class="btn btn-info" href="edit.php"> <i class="fa fa-edit"></i> </a>
                        </td>
                        <td>
                            <a class="btn btn-danger" href="delete.php"> <i class="fa fa-close"></i> </a>
                        </td>
                    </tr>
                
                </tbody>
            </table>
        </div>
    </div>

<?php  include('inc/footer.php'); ?>

 
  